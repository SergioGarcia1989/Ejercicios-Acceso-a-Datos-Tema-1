/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package verficheros;

/**
 *
 * @author Usuario
 */
public class lineta
{
    String dia;
    String mes;
    String anyo;
    int horatotal;
    String IP;

    public lineta(String dia, String mes, String anyo, int horatotal, String IP)
    {
        this.dia = dia;
        this.mes = mes;
        this.anyo = anyo;
        this.horatotal = horatotal;
        this.IP = IP;
    }

    public String getIP()
    {
        return IP;
    }
    
    
   
    
    

    public int getHoratotal()
    {
        return horatotal;
    }

    

   

    public String getDia()
    {
        return dia;
    }

    public String getMes()
    {
        return mes;
    }

    public String getAnyo()
    {
        return anyo;
    }
    
    
}
