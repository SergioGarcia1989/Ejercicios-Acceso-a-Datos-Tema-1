/*
 *Sergio Garcia Balsas
Crea un programa que pida al usuario el nombre de un fichero de log de Apache
y vuelque a un segundo fichero (cuyo nombre indicará el usuario) las líneas
separadas por más de "n" segundos (también escogidos por el usuario).

Mejora deseable: que no muestre sólo la líne anterior al evento, sino las 10 anteriores.
 */
package verficheros;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class VerFicheros
{

   
    public static void main(String[] args)
    {
       Scanner teclado = new Scanner (System.in);
        String nombreFichero="";
        int numero=0;
        
        if (args.length == 0)
        {
            System.out.println(" Nombre del fichero? ");
            nombreFichero = teclado.nextLine();
            System.out.println("Numero de Segundos transcurridos desde ataque? ");
            numero = teclado.nextInt();
        }
        else
        {
            nombreFichero = args[0];
            numero = Integer.parseInt(args[1]);
        }
        
        try
        {
            BufferedReader ficheroEntrada = new BufferedReader(
                    new FileReader(new File(nombreFichero)));
            String linea = "";
            
           
            PrintWriter ficheroSalida = new PrintWriter("fichero.txt");
            
            List<String> l = new ArrayList<>();
            List<lineta> listadelinetas = new ArrayList<>();
            
            do
            {
                linea = ficheroEntrada.readLine();
                
                if (linea != null)
                {
                    System.out.println("----DEBUG-----------");
                    
                    System.out.println(linea);
                    l.add(linea);
                    
                    
                    
                    String[] partes = linea.split("]");
                    //Debugging
                    System.out.println("IP " + partes[0]);
                    
                    String[] SacarIP = partes[0].split(" ");
                    System.out.println("SacarIP" + SacarIP[0]);
                    String IP = SacarIP[0];
                    
                    String myPart = partes[0];
                    String[] partesReducidas = myPart.split(" ");
                   
                    
                    System.out.println("Fecha " + partesReducidas[3]);
                    String fecha = partesReducidas[3];
                    String dia = fecha.substring(1,3);
                    System.out.println("Dia " + dia);
                    String mes = fecha.substring(4,7);
                    System.out.println("Mes " + mes );
                    String anyo = fecha.substring(8, 12);
                    System.out.println("Año " + anyo );
                    
                   
                    
                    //Horas
                    String hora = fecha.substring(13,15);
                    System.out.println("Hora " + hora );
                     
                    String minuto = fecha.substring(16,18);
                    System.out.println("minuto " + minuto );
                     
                    String segundo = fecha.substring(19,21);
                    System.out.println("segundo " + segundo );
                    
                    int horaSegundos = Integer.parseInt(hora) * 3600;
                    
                    int minutoParseado = Integer.parseInt(minuto) * 60;
                    
                    int segundos = Integer.parseInt(segundo);
                    
                    int horatotal = horaSegundos + minutoParseado + segundos;
                    
                    lineta li = new lineta (dia, mes, anyo, horatotal, IP);
                    listadelinetas.add(li);
                    
                    System.out.println("------------------------------");
                    
                    System.out.println("..Mostrando IPs que se ha conectado " +
                            "en los " + numero + " segundo que ha indicado");
                    
                    
                    
                       
                }
            }
            while (linea != null);
            boolean m = false;
            for (int i = 1  ; i < listadelinetas.size() ; i++)
                    {
                        if ((listadelinetas.get(i).getAnyo()
                                .contains(listadelinetas.get(i-1).getAnyo())
                                &&
                              (listadelinetas.get(i).getMes()
                                .contains(listadelinetas.get(i-1).getMes())))  
                                &&
                              (listadelinetas.get(i).getDia()
                                .contains(listadelinetas.get(i-1).getDia())) 
                                && 
                                (listadelinetas.get(i).getHoratotal() 
                                -  listadelinetas.get(i - 1).getHoratotal() 
                                 == numero)
                                )
                           
                        {
                            m = true;
                            System.out.println(listadelinetas.get(i).getIP());
                            System.out.println("Volcando a fichero..");
                            ficheroSalida.println(listadelinetas.get(i).getIP());
                        }
                       
                       
                    }
            
                     if (! m)
                     {
                         System.out.println("no");
                     }
            
           ficheroEntrada.close();
           ficheroSalida.close();
        } 
        catch (FileNotFoundException ex)
        {
            System.err.println("Fichero no encontrado");
        } 
        catch (IOException ex)
        {
            System.err.println("Error de entrada salida");
        } 
    }
}
